# دليل الإعداد - تطبيق YouTube Video Scraper

## مرحباً بك! 👋

هذا دليل شامل لإعداد وتشغيل تطبيق YouTube Video Scraper على جهازك.

---

## المتطلبات الأساسية

قبل البدء، تأكد من توفر:

1. **Android Studio** (الإصدار 2023.1 أو أحدث)
   - [تحميل Android Studio](https://developer.android.com/studio)

2. **Java Development Kit (JDK)** (الإصدار 11 أو أحدث)
   - يأتي مع Android Studio تلقائياً

3. **Android SDK** (المستوى 24 أو أحدث)
   - يتم تثبيته مع Android Studio

4. **اتصال إنترنت** (لتحميل الحزم والمكتبات)

---

## خطوات التثبيت

### الخطوة 1: فتح المشروع

1. افتح **Android Studio**
2. اختر **File** → **Open**
3. انتقل إلى مجلد `YouTubeVideoScraper`
4. اضغط **OK**

### الخطوة 2: تحميل الحزم

Android Studio سيقوم تلقائياً بـ:
- تحميل Gradle
- تحميل جميع المكتبات المطلوبة
- بناء المشروع

**إذا لم يحدث تلقائياً:**
- اذهب إلى **Build** → **Make Project**
- أو اضغط `Ctrl+F9` (Windows/Linux) أو `Cmd+F9` (Mac)

### الخطوة 3: إعداد جهاز المحاكاة (Emulator)

**إذا لم تكن لديك جهاز حقيقي:**

1. اذهب إلى **Tools** → **Device Manager**
2. اضغط **Create Device**
3. اختر جهاز (مثل Pixel 5)
4. اختر نسخة Android (مثل Android 13)
5. اضغط **Finish**

### الخطوة 4: تشغيل التطبيق

**على محاكي:**
1. اختر **Run** → **Run 'app'**
2. اختر الجهاز من القائمة
3. اضغط **OK**

**على جهاز حقيقي:**
1. وصّل جهازك عبر USB
2. فعّل **USB Debugging** على الجهاز:
   - اذهب إلى **Settings** → **About Phone**
   - اضغط على **Build Number** 7 مرات
   - عد إلى **Settings** → **Developer Options**
   - فعّل **USB Debugging**
3. اختر **Run** → **Run 'app'**
4. اختر جهازك من القائمة

---

## هيكل المشروع

```
YouTubeVideoScraper/
│
├── app/                                    # مجلد التطبيق الرئيسي
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/youtubescraper/
│   │   │   │   ├── MainActivity.kt              # الشاشة الرئيسية
│   │   │   │   ├── VideoPlayerActivity.kt       # شاشة التشغيل
│   │   │   │   ├── YouTubeVideo.kt              # نموذج البيانات
│   │   │   │   ├── YouTubeScraper.kt            # وحدة Web Scraping
│   │   │   │   └── VideoAdapter.kt              # محول القائمة
│   │   │   │
│   │   │   ├── res/
│   │   │   │   ├── layout/                      # تصاميم الشاشات
│   │   │   │   │   ├── activity_main.xml
│   │   │   │   │   ├── item_video.xml
│   │   │   │   │   └── activity_video_player.xml
│   │   │   │   │
│   │   │   │   ├── values/                      # الموارد
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   ├── colors.xml
│   │   │   │   │   └── styles.xml
│   │   │   │   │
│   │   │   │   └── drawable/                    # الرسوميات
│   │   │   │       └── search_background.xml
│   │   │   │
│   │   │   └── AndroidManifest.xml              # إعدادات التطبيق
│   │   │
│   │   └── test/                                # الاختبارات
│   │
│   ├── build.gradle                             # إعدادات البناء
│   └── proguard-rules.pro                       # قواعد ProGuard
│
├── build.gradle                                 # إعدادات البناء الرئيسية
├── settings.gradle                              # إعدادات Gradle
├── gradle.properties                            # خصائص Gradle
├── README.md                                    # الدليل الرئيسي
└── SETUP_AR.md                                  # هذا الملف
```

---

## شرح الملفات المهمة

### 1. **YouTubeScraper.kt** - وحدة استخراج البيانات
```kotlin
// البحث عن فيديوهات
val videos = YouTubeScraper.searchVideos("اسم الفيديو")

// الحصول على تفاصيل الفيديو
val video = YouTubeScraper.getVideoDetails("videoId")
```

**الدوال:**
- `searchVideos(query)` - البحث عن فيديوهات
- `getVideoDetails(videoId)` - الحصول على التفاصيل
- `extractVideoId(url)` - استخراج معرف الفيديو

### 2. **MainActivity.kt** - الشاشة الرئيسية
- حقل البحث
- زر البحث والمسح
- قائمة الفيديوهات

### 3. **VideoPlayerActivity.kt** - شاشة التشغيل
- مشغل الفيديو
- أزرار النسخ والمشاركة
- فتح في يوتيوب

### 4. **VideoAdapter.kt** - محول القائمة
- عرض الفيديوهات
- معالجة النقرات
- تحميل الصور

---

## المكتبات المستخدمة

| المكتبة | الاستخدام |
|--------|----------|
| **JSoup** | استخراج البيانات من صفحات الويب |
| **Glide** | تحميل وعرض الصور |
| **OkHttp** | طلبات HTTP |
| **Retrofit** | REST API |
| **Kotlin Coroutines** | البرمجة غير المتزامنة |
| **Android YouTube Player** | تشغيل فيديوهات يوتيوب |

---

## كيفية الاستخدام

### البحث عن الفيديوهات:

1. **افتح التطبيق**
2. **اكتب كلمة البحث** في حقل البحث
   - مثال: "تعليم البرمجة"
3. **اضغط على زر "Search"** أو اضغط Enter
4. **انتظر** قليلاً حتى يتم البحث
5. **ستظهر النتائج** في القائمة

### تشغيل الفيديو:

1. **اضغط على زر "Play"** على أي فيديو
2. **سيتم فتح شاشة التشغيل**
3. **الفيديو سيبدأ التشغيل تلقائياً**

### نسخ الرابط الكامل:

1. **اضغط على زر "Copy Link"**
2. **سيتم نسخ الرابط الكامل**
3. **يمكنك لصقه في أي مكان**

### نسخ معرف الفيديو:

1. **اضغط على زر "Copy ID"**
2. **سيتم نسخ معرف الفيديو (Video ID)**

---

## استكشاف الأخطاء والمشاكل

### المشكلة: "No videos found"
**الحل:**
- ✓ تأكد من اتصالك بالإنترنت
- ✓ حاول بحث آخر
- ✓ تأكد من صحة كلمة البحث

### المشكلة: "Failed to load image"
**الحل:**
- ✓ تأكد من اتصالك بالإنترنت
- ✓ أعد تشغيل التطبيق

### المشكلة: "Video player not loading"
**الحل:**
- ✓ تأكد من تثبيت تطبيق يوتيوب
- ✓ تأكد من صحة معرف الفيديو

### المشكلة: "Build failed"
**الحل:**
- ✓ اذهب إلى **File** → **Invalidate Caches**
- ✓ اختر **Invalidate and Restart**
- ✓ حاول البناء مرة أخرى

### المشكلة: "Gradle sync failed"
**الحل:**
- ✓ اذهب إلى **File** → **Sync Now**
- ✓ تأكد من اتصالك بالإنترنت
- ✓ جرب **Build** → **Clean Project**

---

## الصلاحيات المطلوبة

التطبيق يحتاج إلى الصلاحيات التالية:

| الصلاحية | الاستخدام |
|---------|----------|
| **INTERNET** | للاتصال بالإنترنت والبحث |
| **ACCESS_NETWORK_STATE** | للتحقق من الاتصال |
| **WRITE_EXTERNAL_STORAGE** | لحفظ الفيديوهات (اختياري) |
| **READ_EXTERNAL_STORAGE** | لقراءة الملفات (اختياري) |

---

## نصائح للتطوير

### إضافة مميزة جديدة:

1. **أنشئ ملف Kotlin جديد** في `java/com/example/youtubescraper/`
2. **أضف الكود الخاص بك**
3. **أضف الواجهة في `activity_main.xml`** إذا لزم الأمر
4. **اختبر التطبيق**

### تصحيح الأخطاء (Debugging):

1. **اضغط على سطر الكود** الذي تريد وضع نقطة توقف عليه
2. **اضغط على رقم السطر** لإضافة breakpoint
3. **شغّل التطبيق** في وضع Debug
4. **استخدم نافذة Debugger** لتتبع المتغيرات

---

## الخطوات التالية

بعد تثبيت التطبيق بنجاح:

1. ✅ جرب البحث عن فيديوهات مختلفة
2. ✅ اختبر تشغيل الفيديوهات
3. ✅ جرب نسخ الروابط
4. ✅ شارك التطبيق مع الآخرين

---

## مراجع مفيدة

- [Android Developer Documentation](https://developer.android.com/docs)
- [Kotlin Documentation](https://kotlinlang.org/docs/)
- [JSoup Documentation](https://jsoup.org/)
- [Android Studio Help](https://developer.android.com/studio/intro)

---

## الدعم والمساعدة

إذا واجهت أي مشاكل:

1. **تحقق من الأخطاء** في نافذة Logcat
2. **ابحث عن الحل** في المراجع أعلاه
3. **اطلب المساعدة** من المجتمع

---

## ملاحظات مهمة

⚠️ **تحذير قانوني:**
- هذا التطبيق يستخدم Web Scraping
- احترم شروط الخدمة الخاصة بيوتيوب
- لا تستخدم البيانات لأغراض تجارية بدون إذن

---

**تم إنشاء هذا الدليل لمساعدتك على البدء بسرعة! 🚀**

**صُنع بـ ❤️ للمطورين العرب**

