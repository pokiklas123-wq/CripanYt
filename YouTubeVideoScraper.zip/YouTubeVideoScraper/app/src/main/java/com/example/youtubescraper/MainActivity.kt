package com.example.youtubescraper

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.youtubescraper.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var videoAdapter: VideoAdapter
    private val videos = mutableListOf<YouTubeVideo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        setupRecyclerView()
        setupSearchListener()
    }

    private fun setupUI() {
        // Set toolbar title
        supportActionBar?.title = "YouTube Video Scraper"

        // Search button click
        binding.searchButton.setOnClickListener {
            performSearch()
        }

        // Clear button click
        binding.clearButton.setOnClickListener {
            binding.searchEditText.text.clear()
            videos.clear()
            videoAdapter.notifyDataSetChanged()
        }
    }

    private fun setupRecyclerView() {
        videoAdapter = VideoAdapter(videos) { video ->
            // Open video in player
            val intent = Intent(this, VideoPlayerActivity::class.java)
            intent.putExtra("videoId", video.videoId)
            intent.putExtra("title", video.title)
            intent.putExtra("url", video.url)
            startActivity(intent)
        }

        binding.videosRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = videoAdapter
        }
    }

    private fun setupSearchListener() {
        binding.searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                return@setOnEditorActionListener true
            }
            false
        }
    }

    private fun performSearch() {
        val query = binding.searchEditText.text.toString().trim()

        if (query.isEmpty()) {
            Toast.makeText(this, "Please enter a search query", Toast.LENGTH_SHORT).show()
            return
        }

        // Show loading state
        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.statusTextView.text = "Searching..."

        lifecycleScope.launch {
            try {
                val results = YouTubeScraper.searchVideos(query)

                if (results.isEmpty()) {
                    binding.statusTextView.text = "No videos found"
                    videos.clear()
                    videoAdapter.notifyDataSetChanged()
                } else {
                    binding.statusTextView.text = "Found ${results.size} videos"
                    videoAdapter.updateVideos(results)
                }
            } catch (e: Exception) {
                binding.statusTextView.text = "Error: ${e.message}"
                Toast.makeText(this@MainActivity, "Search failed: ${e.message}", Toast.LENGTH_SHORT)
                    .show()
            } finally {
                binding.progressBar.visibility = android.view.View.GONE
            }
        }
    }
}

