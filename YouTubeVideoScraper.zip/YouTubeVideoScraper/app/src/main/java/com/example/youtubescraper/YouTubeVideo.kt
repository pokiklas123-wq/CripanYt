package com.example.youtubescraper

data class YouTubeVideo(
    val videoId: String,
    val title: String,
    val thumbnail: String,
    val url: String,
    val channel: String = "Unknown",
    val duration: String = "Unknown"
)

