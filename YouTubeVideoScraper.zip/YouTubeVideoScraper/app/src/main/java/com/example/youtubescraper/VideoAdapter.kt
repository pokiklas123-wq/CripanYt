package com.example.youtubescraper

import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.youtubescraper.databinding.ItemVideoBinding

class VideoAdapter(
    private val videos: MutableList<YouTubeVideo>,
    private val onVideoClick: (YouTubeVideo) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    inner class VideoViewHolder(private val binding: ItemVideoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(video: YouTubeVideo) {
            binding.apply {
                // Load thumbnail
                Glide.with(root.context)
                    .load(video.thumbnail)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_gallery)
                    .into(thumbnailImageView)

                // Set title
                titleTextView.text = video.title

                // Set channel
                channelTextView.text = video.channel

                // Play button click
                playButton.setOnClickListener {
                    onVideoClick(video)
                }

                // Copy link button
                copyLinkButton.setOnClickListener {
                    copyToClipboard(root.context, video.url)
                    Toast.makeText(root.context, "Link copied!", Toast.LENGTH_SHORT).show()
                }

                // Copy video ID button
                copyIdButton.setOnClickListener {
                    copyToClipboard(root.context, video.videoId)
                    Toast.makeText(root.context, "Video ID copied!", Toast.LENGTH_SHORT).show()
                }

                // Card click
                root.setOnClickListener {
                    onVideoClick(video)
                }
            }
        }

        private fun copyToClipboard(context: Context, text: String) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = android.content.ClipData.newPlainText("YouTube Link", text)
            clipboard.setPrimaryClip(clip)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VideoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        holder.bind(videos[position])
    }

    override fun getItemCount(): Int = videos.size

    fun updateVideos(newVideos: List<YouTubeVideo>) {
        videos.clear()
        videos.addAll(newVideos)
        notifyDataSetChanged()
    }

    fun addVideos(newVideos: List<YouTubeVideo>) {
        val startPosition = videos.size
        videos.addAll(newVideos)
        notifyItemRangeInserted(startPosition, newVideos.size)
    }
}

