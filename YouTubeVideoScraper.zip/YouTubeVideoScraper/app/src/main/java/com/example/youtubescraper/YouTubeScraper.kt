package com.example.youtubescraper

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

object YouTubeScraper {
    private const val TAG = "YouTubeScraper"
    private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    private const val YOUTUBE_SEARCH_URL = "https://www.youtube.com/results?search_query="

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Search for videos on YouTube using web scraping
     */
    suspend fun searchVideos(query: String): List<YouTubeVideo> = withContext(Dispatchers.IO) {
        return@withContext try {
            val searchUrl = YOUTUBE_SEARCH_URL + query.replace(" ", "+")
            Log.d(TAG, "Searching for: $query at $searchUrl")

            val request = Request.Builder()
                .url(searchUrl)
                .addHeader("User-Agent", USER_AGENT)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e(TAG, "Search failed with code: ${response.code}")
                return@withContext emptyList()
            }

            val html = response.body?.string() ?: return@withContext emptyList()
            val document = Jsoup.parse(html)

            val videos = mutableListOf<YouTubeVideo>()

            // Extract video data from the page
            val videoElements = document.select("a#video-title")
            
            for (element in videoElements.take(20)) { // Limit to 20 results
                try {
                    val title = element.attr("title").takeIf { it.isNotEmpty() } ?: element.text()
                    val href = element.attr("href")
                    
                    if (href.isEmpty() || !href.contains("watch?v=")) continue

                    val videoId = extractVideoId(href)
                    if (videoId.isEmpty()) continue

                    val thumbnail = "https://img.youtube.com/vi/$videoId/mqdefault.jpg"
                    val fullUrl = "https://www.youtube.com$href"

                    val video = YouTubeVideo(
                        videoId = videoId,
                        title = title,
                        thumbnail = thumbnail,
                        url = fullUrl
                    )

                    videos.add(video)
                    Log.d(TAG, "Found video: $title ($videoId)")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing video element: ${e.message}")
                }
            }

            Log.d(TAG, "Total videos found: ${videos.size}")
            videos
        } catch (e: Exception) {
            Log.e(TAG, "Error searching videos: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Extract video ID from YouTube URL
     */
    private fun extractVideoId(url: String): String {
        val patterns = listOf(
            "(?:youtube\\.com/watch\\?v=|youtu\\.be/)([^&\\n?#]+)".toRegex(),
            "youtube\\.com/embed/([^&\\n?#]+)".toRegex(),
            "youtube\\.com/v/([^&\\n?#]+)".toRegex()
        )

        for (pattern in patterns) {
            val match = pattern.find(url)
            if (match != null && match.groupValues.size > 1) {
                return match.groupValues[1]
            }
        }
        return ""
    }

    /**
     * Get video details from a specific video URL
     */
    suspend fun getVideoDetails(videoId: String): YouTubeVideo? = withContext(Dispatchers.IO) {
        return@withContext try {
            val url = "https://www.youtube.com/watch?v=$videoId"
            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", USER_AGENT)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return@withContext null

            val html = response.body?.string() ?: return@withContext null
            val document = Jsoup.parse(html)

            // Extract title
            val title = document.select("meta[name=title]").attr("content")
                .takeIf { it.isNotEmpty() }
                ?: document.select("h1.title").text()

            // Extract channel
            val channel = document.select("a[href*='/channel/']").first()?.text() ?: "Unknown"

            val thumbnail = "https://img.youtube.com/vi/$videoId/maxresdefault.jpg"
            val fullUrl = "https://www.youtube.com/watch?v=$videoId"

            YouTubeVideo(
                videoId = videoId,
                title = title,
                thumbnail = thumbnail,
                url = fullUrl,
                channel = channel
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error getting video details: ${e.message}", e)
            null
        }
    }
}

