package com.example.youtubescraper

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.youtubescraper.databinding.ActivityVideoPlayerBinding
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener

class VideoPlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoPlayerBinding
    private var videoId: String = ""
    private var videoUrl: String = ""
    private var videoTitle: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get video data from intent
        videoId = intent.getStringExtra("videoId") ?: ""
        videoTitle = intent.getStringExtra("title") ?: "Video"
        videoUrl = intent.getStringExtra("url") ?: ""

        setupUI()
        setupYouTubePlayer()
        setupButtons()
    }

    private fun setupUI() {
        supportActionBar?.title = videoTitle
        binding.videoTitleTextView.text = videoTitle
    }

    private fun setupYouTubePlayer() {
        if (videoId.isEmpty()) {
            binding.youtubePlayerView.visibility = android.view.View.GONE
            binding.videoTitleTextView.text = "Invalid video ID"
            return
        }

        binding.youtubePlayerView.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                youTubePlayer.cueVideo(videoId, 0f)
            }
        })

        lifecycle.addObserver(binding.youtubePlayerView)
    }

    private fun setupButtons() {
        // Copy link button
        binding.copyLinkButton.setOnClickListener {
            copyToClipboard(videoUrl)
            Toast.makeText(this, "Link copied to clipboard!", Toast.LENGTH_SHORT).show()
        }

        // Copy video ID button
        binding.copyIdButton.setOnClickListener {
            copyToClipboard(videoId)
            Toast.makeText(this, "Video ID copied to clipboard!", Toast.LENGTH_SHORT).show()
        }

        // Open in YouTube button
        binding.openInYouTubeButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl))
            startActivity(intent)
        }

        // Share button
        binding.shareButton.setOnClickListener {
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, "$videoTitle\n$videoUrl")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Share video"))
        }

        // Back button
        binding.backButton.setOnClickListener {
            finish()
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = android.content.ClipData.newPlainText("YouTube Link", text)
        clipboard.setPrimaryClip(clip)
    }

    override fun onDestroy() {
        binding.youtubePlayerView.release()
        super.onDestroy()
    }
}

