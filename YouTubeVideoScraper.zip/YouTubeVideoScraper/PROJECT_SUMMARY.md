# YouTube Video Scraper - ملخص المشروع

## 📱 نظرة عامة

تطبيق أندرويد متقدم يجلب فيديوهات يوتيوب عبر خانة البحث باستخدام تقنية Web Scraping مع مكتبة JSoup.

## ✨ المميزات الرئيسية

✅ **البحث عن الفيديوهات** - ابحث عن أي فيديو على يوتيوب
✅ **استخراج البيانات** - استخراج العنوان والصورة المصغرة باستخدام JSoup
✅ **عرض الفيديوهات** - عرض منظم مع الصور المصغرة
✅ **تشغيل الفيديو** - تشغيل مباشر من داخل التطبيق
✅ **نسخ الرابط** - نسخ رابط الفيديو الكامل بضغطة زر
✅ **نسخ معرف الفيديو** - نسخ Video ID بسهولة
✅ **مشاركة الفيديو** - شارك مع الآخرين
✅ **فتح في يوتيوب** - افتح الفيديو في تطبيق يوتيوب

## 🏗️ هيكل المشروع

```
YouTubeVideoScraper/
├── app/
│   ├── src/main/java/com/example/youtubescraper/
│   │   ├── MainActivity.kt              (الشاشة الرئيسية)
│   │   ├── VideoPlayerActivity.kt       (شاشة التشغيل)
│   │   ├── YouTubeVideo.kt              (نموذج البيانات)
│   │   ├── YouTubeScraper.kt            (Web Scraping)
│   │   └── VideoAdapter.kt              (محول RecyclerView)
│   │
│   ├── src/main/res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml
│   │   │   ├── item_video.xml
│   │   │   └── activity_video_player.xml
│   │   │
│   │   ├── values/
│   │   │   ├── strings.xml
│   │   │   ├── colors.xml
│   │   │   └── styles.xml
│   │   │
│   │   └── drawable/
│   │       └── search_background.xml
│   │
│   └── build.gradle
│
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
├── SETUP_AR.md
└── PROJECT_SUMMARY.md (هذا الملف)
```

## 🛠️ التقنيات المستخدمة

| التقنية | الإصدار | الاستخدام |
|--------|--------|----------|
| Kotlin | 1.9.0 | لغة البرمجة الأساسية |
| Android SDK | 34 | نسخة Android المستهدفة |
| JSoup | 1.16.1 | Web Scraping |
| Glide | 4.16.0 | تحميل الصور |
| OkHttp | 4.11.0 | طلبات HTTP |
| Retrofit | 2.10.0 | REST API |
| Kotlin Coroutines | 1.7.3 | البرمجة غير المتزامنة |
| Android YouTube Player | Latest | تشغيل الفيديوهات |

## 📋 الملفات الرئيسية

### 1. YouTubeScraper.kt
**وحدة استخراج البيانات من يوتيوب**

الدوال الرئيسية:
- `searchVideos(query: String)` - البحث عن فيديوهات
- `getVideoDetails(videoId: String)` - الحصول على تفاصيل الفيديو
- `extractVideoId(url: String)` - استخراج معرف الفيديو

الميزات:
- استخدام JSoup لاستخراج البيانات
- معالجة الأخطاء الشاملة
- دعم Coroutines للعمليات غير المتزامنة

### 2. MainActivity.kt
**الشاشة الرئيسية للتطبيق**

المكونات:
- حقل البحث
- زر البحث والمسح
- RecyclerView لعرض الفيديوهات
- شريط الحالة

### 3. VideoPlayerActivity.kt
**شاشة تشغيل الفيديو**

الميزات:
- مشغل يوتيوب المدمج
- نسخ الرابط الكامل
- نسخ معرف الفيديو
- مشاركة الفيديو
- فتح في يوتيوب

### 4. VideoAdapter.kt
**محول RecyclerView**

الوظائف:
- عرض قائمة الفيديوهات
- تحميل الصور المصغرة
- معالجة النقرات على الأزرار
- نسخ الروابط والمعرفات

## 🚀 كيفية البدء

### المتطلبات:
- Android Studio 2023.1+
- JDK 11+
- Android SDK 24+

### خطوات التثبيت:
1. فتح المشروع في Android Studio
2. تحميل الحزم (Build > Make Project)
3. إعداد جهاز محاكاة أو وصل جهاز حقيقي
4. تشغيل التطبيق (Run > Run 'app')

## 📱 واجهة المستخدم

### الشاشة الرئيسية:
- حقل بحث بتصميم حديث
- أزرار البحث والمسح
- قائمة الفيديوهات مع الصور المصغرة
- عرض حالة البحث

### بطاقة الفيديو:
- صورة مصغرة
- عنوان الفيديو
- اسم القناة
- أزرار (Play, Copy Link, Copy ID)

### شاشة التشغيل:
- مشغل الفيديو
- عنوان الفيديو
- أزرار (Copy Link, Copy ID, Open in YouTube, Share, Back)

## 🔧 الصلاحيات المطلوبة

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

## 📊 معلومات البناء

- **Minimum SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **Compile SDK**: 34
- **Language**: Kotlin
- **Build System**: Gradle

## 🎨 التصميم

- **Theme**: Material Design
- **Colors**: 
  - Red (#FFE53935) - اللون الأساسي
  - Blue (#FF1E88E5) - الأزرار الثانوية
  - Green (#FF43A047) - أزرار النسخ
  - Gray (#FF757575) - الألوان الثانوية

## 🔒 الأمان والخصوصية

- استخدام HTTPS للاتصالات
- معالجة آمنة للبيانات
- عدم حفظ بيانات المستخدم الشخصية
- احترام سياسة يوتيوب

## ⚠️ ملاحظات قانونية

- التطبيق يستخدم Web Scraping
- احترم شروط الخدمة الخاصة بيوتيوب
- لا تستخدم البيانات لأغراض تجارية بدون إذن
- احترم حقوق المؤلفين والملكية الفكرية

## 📝 الترخيص

MIT License - يمكنك استخدام واستعديل الكود بحرية

## 🤝 المساهمة

نرحب بالمساهمات! يمكنك:
- الإبلاغ عن الأخطاء
- اقتراح مميزات جديدة
- تحسين الكود

## 📚 المراجع

- [Android Developer Docs](https://developer.android.com/docs)
- [Kotlin Documentation](https://kotlinlang.org/docs/)
- [JSoup Documentation](https://jsoup.org/)
- [Material Design](https://material.io/design)

## 🎯 الإضافات المستقبلية

- 🔄 تحميل الفيديوهات
- ⭐ حفظ الفيديوهات المفضلة
- 📜 سجل البحث
- 🔍 تصفية النتائج
- 💬 عرض التعليقات
- 📊 عرض الإحصائيات
- 🌍 دعم لغات متعددة

## 👨‍💻 معلومات المطور

صُنع بـ ❤️ للمطورين العرب

---

**آخر تحديث**: أكتوبر 2025
**الإصدار**: 1.0
